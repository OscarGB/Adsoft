package testers;

import console.FullConsole;

/**
 * Clase Tester4
 * @author Oscar Gomez
 * @author Jose Ignacio Gomez
 */
public class Tester4 {

	public static void main(String[] args) {
		FullConsole console = new FullConsole();
		console.run();
	}

}
