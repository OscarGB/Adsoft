package unit;

/**
 * Enumeracion de Quantities
 * @author Oscar Gomez
 * @author Jose Ignacio Gomez
 */
public enum Quantity {
	L, // Longitud 
	t; // Tiempo
}
